<?php
wp_enqueue_script('wow.min.js', get_template_directory_uri() . '/assets/js/wow.min.js', array('jquery'), '1.0.0', true);
wp_enqueue_style('animate-css', get_template_directory_uri() . '/assets/css/animate.css', array(), null);