<?php
wp_enqueue_script('matchHeight-js', get_template_directory_uri() . '/assets/js/jquery.matchHeight-min.js', array('jquery'), '1.0.0', true);
?>