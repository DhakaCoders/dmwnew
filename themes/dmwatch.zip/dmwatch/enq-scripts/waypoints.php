<?php
wp_enqueue_script('waypoints.js', get_template_directory_uri() . '/assets/js/waypoints.js', array('jquery'), '2.0.3', true);
wp_enqueue_script('counterup.js', get_template_directory_uri() . '/assets/js/jquery.counterup.min.js', array('jquery'), '1.0.0', true);
?>