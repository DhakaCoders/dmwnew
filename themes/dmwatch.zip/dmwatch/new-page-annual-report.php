<?php 
/*
  Template Name: Anual Report
*/
get_header();
?>
<span id="recentID" data-postid="<?php echo $recentID; ?>" style="display: none;"></span>
<?php 
  $pyears = $ptype = ''; 
  if ( isset($_GET['type']) && !empty($_GET['type'])){
    $ptype = $_GET['type'];
  } 

  if ( isset($_GET['years']) && !empty($_GET['years'])){
    $pyears = $_GET['years'];
  }
?>
<section class="our-project-filter-hdr-sec publicationsFilter">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="our-project-filter-hdr hasAnim">
          <h2 class="opfhdr-title doAnim">Filter Annual Reports</h2>
        </div>
        <div class="our-project-filter-btns">
          <form action="" method="get">
          <ul class="reset-list clearfix">
            <?php 
            $types = get_terms( array(
              'taxonomy' => 'report_type',
              'hide_empty' => false,
              'parent' => 0
            ) );
            ?>
            <li>
              <div class="filter-btn-cntlr">
                <div class="filter-btn"><button type="button"><span>Type</span></button></div>
                <?php if ( ! empty( $types ) && ! is_wp_error( $types ) ){  ?>
                <div class="filter-btn-dorpdown">
                  <?php $i = 10; foreach ( $types as $type ) { ?>
                  <div class="filter-btn-dorpdown-item">
                    <div class="filter-check-row clearfix">
                      <input type="radio" id="pa<?php echo $i; ?>" <?php echo ( $ptype == $type->slug )? 'checked': ''; ?> name="type" value="<?php echo $type->slug; ?>">
                      <span class="checkmark"></span> 
                      <label for="pa<?php echo $i; ?>"><?php echo $type->name; ?></label> 
                    </div>
                  </div>
                  <?php $i++; } ?>
                </div>
                <?php } ?>
              </div>
            </li>
            <?php 
            $years = get_terms( array(
              'taxonomy' => 'report_year',
              'hide_empty' => false,
              'parent' => 0
            ) );
            ?>
            <li>
              <div class="filter-btn-cntlr">
                <div class="filter-btn"><button type="button"><span>Year</span></button></div>
                <?php if ( ! empty( $years ) && ! is_wp_error( $years ) ){  ?>
                  <div class="filter-btn-dorpdown">
                    <?php $i = 20; foreach ( $years as $year ) { ?>
                    <div class="filter-btn-dorpdown-item">
                      <div class="filter-check-row clearfix">
                        <input type="radio" id="pa<?php echo $i; ?>" <?php echo ( $pyears == $year->slug )? 'checked': ''; ?> name="years" value="<?php echo $year->slug; ?>">
                        <span class="checkmark"></span> 
                        <label for="pa<?php echo $i; ?>"><?php echo $year->name; ?></label> 
                      </div>
                    </div>
                    <?php $i++; } ?>
                  </div>
                <?php } ?>
              </div>
            </li>
            <li>
              <div class="fl-filter-btn-cntlr">
                <button type="submit">Filter Now</button>
              </div>
            </li>
          </ul>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
<?php
$showN = true; 
if( !empty($ptype) OR !empty($pyears) ):
$showN = false; 
global $wp;
?>
<section class="recent-publicatons exAnnualReports">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="filter-result-hedding">
            <h2 class="opfhdr-title">FILTER RESULT</h2>
            <div class="reset-filter-btn backTopage">
              <button data-url="<?php echo home_url($wp->request); ?>/" class="clearnow" type="reset">Reset Filter</button>
            </div>
        </div>
        <span id="filter" data-type="<?php echo $ptype; ?>" data-year="<?php echo $pyears; ?>" style="display: none;"></span>
        <?php echo do_shortcode('[ajax_search_posts]'); ?>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>

<?php  
if( $showN ):
$thisID = get_the_ID();
$bcontent = get_field('description', $thisID);
?>
<section class="annualReports">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="annualReportsHdr">
            <h2 class="opfhdr-title">Annual Reports</h2>
            <?php if( !empty($bcontent) ) echo wpautop($bcontent); ?>
        </div>
        <?php echo do_shortcode('[ajax_report_posts]'); ?>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>

<?php 
get_template_part('templates/footer', 'top');
get_footer(); 
?>