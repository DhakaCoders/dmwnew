<?php 
/*
Template Name: Our Management
*/
wp_redirect( home_url('management'));
exit();
?>