<?php 
/*
Template Name: Our Projects
*/
wp_redirect( home_url('project'));
exit();
?>