<?php 
wp_enqueue_style('font-awesome', get_template_directory_uri() . '/assets/fonts/font-awesome/font-awesome.css', array(), '5.5.0');
wp_enqueue_style('cbv-custom.fonts', get_template_directory_uri() . '/assets/fonts/custom-fonts.css', array(), '1.0.0');
wp_enqueue_style('cbv-fonts-raleway', 'https://fonts.googleapis.com/css?family=Raleway:300,300i,400,400i,500,500i,600,600i,700,700i,800&display=swap', array(), '1.0.0');
?>