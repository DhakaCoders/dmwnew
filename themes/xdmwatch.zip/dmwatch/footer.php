<?php 
  $spacialArry = array(".", "/", "+", " ", ")", "(", "-");$replaceArray = '';
  $contact = get_field('contactinfo', 'options');
  $address = $contact['address'];
  $gmapsurl = $contact['gmap_url'];
  $email = $contact['email_address'];
  $show_telefoon = $contact['telephone'];
  $telefoon = trim(str_replace($spacialArry, $replaceArray, $show_telefoon));

  $logoObj = get_field('logo_footer', 'options');
  if( is_array($logoObj) ){
    $logo_tag = '<img src="'.$logoObj['url'].'" alt="'.$logoObj['alt'].'" title="'.$logoObj['title'].'">';
  }else{
    $logo_tag = '';
  }
  $smedias = get_field('sociale_media', 'options');
  $ftdescription = get_field('ftdescription', 'options');
  $gmaplink = !empty($gmapsurl)?$gmapsurl: 'javascript:void()';
  $copyright_text = get_field('copyright_text', 'options');
?>
<footer class="footer-wrp">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="footer-inner clearfix">
          <div class="ftr-logo">
            <a href="<?php echo esc_url(home_url('/')); ?>">
              <?php echo $logo_tag; ?>
            </a>
            <div class="ftr-des">
              <?php 
              if( !empty($ftdescription) ) echo wpautop($ftdescription);
              ?>
            </div>
          </div>
          <div class="ftr-menu">
            <div class="ftr-menu-inr">
              <h4 class="ftr-menu-title"><?php _e( 'About us', THEME_NAME ); ?></h4>
              <?php 
                $menuOptionsb = array( 
                    'theme_location' => 'cbv_ft_menu', 
                    'menu_class' => 'reset-list',
                    'container' => '',
                    'container_class' => ''
                  );
                wp_nav_menu( $menuOptionsb ); 
              ?>  
            </div>
          </div>
          <div class="ftr-cnt-menu">
            <div class="ftr-cnt-menu-inr">
              <h4 class="ftr-cnt-menu-title"><?php _e( 'Connect', THEME_NAME ); ?></h4>
              <ul class="reset-list">
                <?php if( !empty($address) ) printf('<li><a href="%s">%s</a></li>', $gmaplink, $address); ?>
                <?php if( !empty($email) ) printf('<li><a href="mailto:%s">%s</a></li>', $email, $email); ?>
                <?php if( !empty($show_telefoon) ) printf('<li><a href="tel:%s">%s</a></li>', $telefoon, $show_telefoon); ?>
              </ul>
            </div>
          </div>
          <div class="ftr-facebook">
            <div class="ftr-facebook-inr">
              <div class="ftr-cnt-socials-media">
                <ul class="reset-list">
                  <li><a href="#"><img src="<?php echo THEME_URI; ?>/assets/images/instagram.png"></a></li>
                  <li><a href="#"><img src="<?php echo THEME_URI; ?>/assets/images/facebook.png"></a></li>
                  <li><a href="#"><img src="<?php echo THEME_URI; ?>/assets/images/whatsapp.png"></a></li>
                  <li><a href="#"><img src="<?php echo THEME_URI; ?>/assets/images/twitter.png"></a></li>
                  <li><a href="#"><img src="<?php echo THEME_URI; ?>/assets/images/linkedin.png"></a></li>
                </ul>
              </div>
              <div class="ftr-fb-area">
                <img src="<?php echo THEME_URI; ?>/assets/images/facebook-img.jpg">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="ftr-copywrite-sec clearfix">
          <div class="developed-by">
            
          </div>
          <div class="ftr-cpwrt">
            <?php if( !empty( $copyright_text ) ) printf( '<span>%s</span>', $copyright_text); ?>
          </div>
        </div>
      </div>
    </div>
  </div> 
  <div class="ftr-msg-icon">
    <img src="<?php echo THEME_URI; ?>/assets/images/msg-icon.png">
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>