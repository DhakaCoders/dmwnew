<?php 
/*
Template Name: Advisor
*/
wp_redirect( home_url('advisor'));
exit();
?>